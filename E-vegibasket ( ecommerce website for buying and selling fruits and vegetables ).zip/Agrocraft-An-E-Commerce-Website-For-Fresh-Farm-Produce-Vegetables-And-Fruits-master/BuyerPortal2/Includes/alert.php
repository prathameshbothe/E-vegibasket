<?php
echo "<script>alert('Cart Is Empty');</script>";
echo "<script>window.open('../bhome.php','_self');</script>";
